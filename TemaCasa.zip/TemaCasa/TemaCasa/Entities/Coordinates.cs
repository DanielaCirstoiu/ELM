﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TemaCasa.Entities
{
    public class Coordinates
    {
        public int i;
        public int j;
        public double val;
    }
}
